package com.example.lesson5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText entered_values;
    float value1, value2;
    boolean mAddition, mSubtract, mMultiplication, mDivision;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        entered_values = findViewById(R.id.enteredValues);

        findViewById(R.id.buttonZero).setOnClickListener(this);
        findViewById(R.id.buttonOne).setOnClickListener(this);
        findViewById(R.id.buttonTwo).setOnClickListener(this);
        findViewById(R.id.buttonThree).setOnClickListener(this);
        findViewById(R.id.buttonFour).setOnClickListener(this);
        findViewById(R.id.buttonFive).setOnClickListener(this);
        findViewById(R.id.buttonSix).setOnClickListener(this);
        findViewById(R.id.buttonSeven).setOnClickListener(this);
        findViewById(R.id.buttonEight).setOnClickListener(this);
        findViewById(R.id.buttonNine).setOnClickListener(this);
        findViewById(R.id.buttonDot).setOnClickListener(this);


        findViewById(R.id.buttonAdd).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value1 = Float.parseFloat(entered_values.getText()+ "");
                mAddition = true;
                entered_values.setText(null);
            }
        });

        findViewById(R.id.buttonSubtract).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value1 = Float.parseFloat(entered_values.getText()+ "");
                mSubtract = true;
                entered_values.setText(null);
            }
        });

        findViewById(R.id.buttonMultiply).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value1 = Float.parseFloat(entered_values.getText()+ "");
                mMultiplication = true;
                entered_values.setText(null);
            }
        });

        findViewById(R.id.buttonDivide).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value1 = Float.parseFloat(entered_values.getText()+ "");
                mDivision = true;
                entered_values.setText(null);
            }
        });

        findViewById(R.id.buttonEqual).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value2 = Float.parseFloat(entered_values.getText()+ "");

                if (mSubtract == true)
                {
                    entered_values.setText(value1-value2+"");
                    mSubtract=false;
                }
                else if(mAddition == true)
                {
                    entered_values.setText(value1+value2+"");
                    mAddition=false;
                }
                else if(mDivision)
                {
                    entered_values.setText(value1/value2+"");
                    mDivision=false;
                }
                else if(mMultiplication)
                {
                    entered_values.setText(value1*value2+"");
                    mMultiplication=false;
                }
            }
        });

        findViewById(R.id.buttonC).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                entered_values.setText("");
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.buttonZero:
                entered_values.setText(entered_values.getText()+"0");
                break;
            case R.id.buttonOne:
                entered_values.setText(entered_values.getText()+"1");
                break;
            case R.id.buttonTwo:
                entered_values.setText(entered_values.getText()+"2");
                break;
            case R.id.buttonThree:
                entered_values.setText(entered_values.getText()+"3");
                break;
            case R.id.buttonFour:
                entered_values.setText(entered_values.getText()+"4");
                break;
            case R.id.buttonFive:
                entered_values.setText(entered_values.getText()+"5");
                break;
            case R.id.buttonSix:
                entered_values.setText(entered_values.getText()+"6");
                break;
            case R.id.buttonSeven:
                entered_values.setText(entered_values.getText()+"7");
                break;
            case R.id.buttonEight:
                entered_values.setText(entered_values.getText()+"8");
                break;
            case R.id.buttonNine:
                entered_values.setText(entered_values.getText()+"9");
                break;
            case R.id.buttonDot:
                entered_values.setText(entered_values.getText()+".");
                break;
        }
    }
}
